# ************************************************************
# Sequel Pro SQL dump
# Versión 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.29)
# Base de datos: gs
# Tiempo de Generación: 2013-09-17 08:58:19 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Volcado de tabla queries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `queries`;

CREATE TABLE `queries` (
  `idQUERIES` int(11) NOT NULL AUTO_INCREMENT,
  `query` text NOT NULL,
  `time_query` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `count` int(11) DEFAULT NULL,
  `time` float DEFAULT '0',
  PRIMARY KEY (`idQUERIES`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Volcado de tabla queries_result
# ------------------------------------------------------------

DROP TABLE IF EXISTS `queries_result`;

CREATE TABLE `queries_result` (
  `idRESOURCES` int(11) NOT NULL,
  `idQUERIES` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `numCitations` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idRESOURCES`,`idQUERIES`),
  KEY `fk_RESOURCES_has_QUERIES_QUERIES1` (`idQUERIES`),
  KEY `fk_RESOURCES_has_QUERIES_RESOURCES1` (`idRESOURCES`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Volcado de tabla resources
# ------------------------------------------------------------

DROP TABLE IF EXISTS `resources`;

CREATE TABLE `resources` (
  `idRESOURCES` int(11) NOT NULL AUTO_INCREMENT,
  `resourceURL` text,
  `citation` text,
  `snippetURL` text NOT NULL,
  `format` varchar(10) DEFAULT NULL,
  `isVersionOf` int(11) DEFAULT NULL,
  `isCiteOf` int(11) DEFAULT NULL,
  `snippetTitle` text,
  `snippetDescription` text,
  `snippetReferences` text,
  PRIMARY KEY (`idRESOURCES`),
  KEY `fk_RESOURCES_RESOURCES1` (`isVersionOf`,`idRESOURCES`),
  KEY `fk_RESOURCES_RESOURCES2` (`isCiteOf`,`idRESOURCES`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
